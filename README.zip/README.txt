Projet Groupomania : Social network

Lancement du projet :
- Clone github repository : https://github.com/ahcene-bouazza/P7_Bouazza_Ahcene_Grouporama.git

- Backend :
    - Rename ".env.exemple" in the backend to ".env" and put the credentials of your database inside
    - npm install
    - nodemon run serve

- Frontend : 
    - npm install
    - npm run serve
 